<?php
return array(
    // 应用版本
    'app_version' => '3.1.3',
    
    // 发布时间
    'release_time' => '20220103',
    
    // 修订版本
    'revise_version' => '5'

);
