<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="robots" content="index, follow" />
<!--通用-->
<meta name="format-detection" content="telephone=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0">
<title>{pboot:pagetitle}</title>
<meta name="description" content="{pboot:sitedescription}" />
<meta name="keywords" content="{pboot:sitekeywords}" />
<meta name="author" content="order by www.adminbuy.cn demo950" />
<link rel="stylesheet" href="{pboot:sitedomain}/skin/css/aos.css" />
<link rel="stylesheet" href="{pboot:sitedomain}/skin/css/bootstrap.min.css" />
<link rel="stylesheet" href="{pboot:sitedomain}/skin/css/idangerous.swiper.css" />
<link rel="stylesheet" href="{pboot:sitedomain}/skin/css/lightbox.css">
<link rel="stylesheet" href="{pboot:sitedomain}/skin/css/app.css" />
<link rel="stylesheet" href="{pboot:sitedomain}/skin/css/apmin.css"/>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries --> 
<!-- WARNING: Respond.js doesn't work if you view the page via file:// --> 
<!--[if lt IE 9]><script src="{pboot:sitedomain}/skin/js/html5shiv.min.js"></script>
<script src="{pboot:sitedomain}/skin/js/respond.min.js"></script><![endif]-->
<style>
.ng-djn-txt {
    text-align: justify;
    text-justify: inter-ideograph;
    word-wrap: break-word;
    word-break: break-all;
}
</style>
</head>
<body >
<!--载入头部-->
<style>
.ng-inpusbox { text-indent:0px;}
</style>
<header id="header" class="navbar navbar-inverse  ng-head ng-bg-fff">
  <div class="am-headthe" aos="fade-down">
    <div class="ng-pull-left">
      <div class="ng-hotline ng-pull-left"><span class="ng-hotline-text ng-pull-left">{dede:global.cfg_gg/}</span></div>
    </div>
    <div class="ng-pull-right"><span class="ng-hotline-icon ng-pull-left"><img src="{pboot:sitedomain}/skin/images/icnphone.png" alt="咨询电话"/></span><span class="ng-hotline-text ng-pull-left"><span>咨询热线 : </span>{pboot:companyphone}</span></div>
  </div>
  <!--icnphone.png-->
  <div class="am-headerv">
    <button class="am-pc-sharebtn ng-pull-right" aos="fade-left"><img src="{pboot:sitedomain}/skin/images/seek.png" alt="搜索"/></button>
    <div class="am-pc-share">
      <div class="ng-fault ng-container">
        <form  name="formsearch" action="{pboot:scaction}" method="get">
          <input type="hidden" name="kwtype" value="0"/>
          <div class="am-pc-share-intext">
            <input type="text" name="q" class="input-text" value=""/>
          </div>
          <div class="am-pc-share-inbtn">
            <input type="submit" value="搜索" />
          </div>
        </form>
      </div>
    </div>
    <div class="am-pc-nav am-ipad-hide" aos="fade-left">
      <ul>
        <li {pboot:if(0=='{sort:scode}')}class='active'{/pboot:if}><a href="{pboot:sitedomain}" class="am-pclink">网站首页</a><span class="am-pclink-borv"><span></span></span></li>
        {pboot:nav num=15 parent=0}
  <li class='{pboot:if('[nav:scode]'=='{sort:tcode}')}class="on"{/pboot:if}'><a href="[nav:link]" class="am-pclink">[nav:name]</a><span class="am-pclink-borv"><span></span></span>
   <div class="am-pc-level">
   <ul>
    {pboot:2nav num=10 parent=[nav:scode]}
    <li><a href="[2nav:link]">[2nav:name]</a></li>
    {/pboot:2nav}
   </ul>
   </div>
  </li>
  {/pboot:nav}
      </ul>
    </div>
    <h1 class="am-logo" aos="fade-right"><a href="/q382h" class="am-logo-link ng-pull-left"><img src="{pboot:sitedomain}/skin/images/logo.png" alt="{pboot:pagetitle}" /></a></h1>
    <button class="ipad-nav-butt" aos="fade-left"><img src="{pboot:sitedomain}/skin/images/snuine.png" alt="{pboot:pagetitle}"/></button>
  </div>
  <div class="ipad-nav">
    <ul>
      <li><a href="{pboot:sitedomain}" {dede:field name=typeid runphp="yes"}(@me=="")? @me="class='ipad-nav-link ipad-nav-link-activate'":@me="class='ipad-nav-link'";{/dede:field}>网站首页</a></li>
      {pboot:nav num=10 parent=0}
      <li><a href="[nav:link]" class="ipad-nav-link">[nav:name]</a></li>
      {/pboot:nav}
    </ul>
    <div class="ipad-nav-down ng-fault"><span onClick="opennav_list()"><img src="{pboot:sitedomain}/skin/images/sidobny.png" alt="{pboot:pagetitle}" /></span></div>
    <div class="ng-insor ng-fault ng-container ng-paddor">
      <div class="ng-fault">
        <div class="row">
          <div class="col-xs-12">
            <div class="ng-insor-itext"><span><span>TEL : </span>{pboot:companyphone}</span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
 
<!--载入主体-->
<div class="am-add"><!-- Slider main container -->
  <div class="swiper-container ng-swiper"><!-- Additional required wrapper -->
    <div class="swiper-wrapper"><!-- Slides --> 
      
      {pboot:list scode=2 num=10 order=date}
      <div class="swiper-slide"><a href="[field:lj/]">
        <div class="swiper-slide"><img src="[list:ico]"></div>
        </a></div>
      {/pboot:list} </div>
    <div class="swiper-pagination"></div>
    <!-- If we need navigation buttons -->
    <div class="swiper-button-prev ng-swiper-ovleft"><img src="{pboot:sitedomain}/skin/images/snne1.png"/></div>
    <div class="swiper-button-next ng-swiper-ovright"><img src="{pboot:sitedomain}/skin/images/snne2.png"/></div>
    <!-- If we need scrollbar --><!--<div class="swiper-scrollbar"></div>--></div>
</div>
<div class="ng-container ng-fault"><!--arop-continer-->
  
  <div class="ng-inmod ng-fault ng-paddor ng-bg-assist">
    <div class="ng-inmod-ini">
      <div class="ng-fault ng-container">
        <div class="ng-inmod-the ng-container ng-bg-assist"><span class="ng-inmod-the-bg ng-inmod-the-bg-left" aos="fade-down-right"><img src="{pboot:sitedomain}/skin/images/insie1.png"/></span><span class="ng-inmod-the-bg ng-inmod-the-bg-right" aos="fade-up-left"><img src="{pboot:sitedomain}/skin/images/insie2.png"/></span> {pboot:sort scode=8}<span class="ng-inmod-the-cn" aos="fade-down">[sort:name]</span>{/pboot:sort} </div>
        <span class="ng-inmod-thebor" aos="fade-up"></span></div>
      <div class="ng-ines ng-fault ng-container" aos="fade-up">
        <ul class="ng-ai-drive1">
          {pboot:nav num=10 parent=5}
          <li><a href="javascript:;" >[nav:name]</a></li>
          {/pboot:nav}
        </ul>
      </div>
      <div class="ng-incontlst ng-fault ng-container ng-ai-drive1_map" aos="fade-up"> {pboot:nav num=10 parent=5}
        <div class="ng-incontlst-doc {dede:global name=itemindex runphp="yes"}(@me==1)? @me="ng-incontlst-doc-show":@me="";{/dede:global}">
          <div class="row"> {pboot:list scode=2 num=10 order=date}
            <div class="ng-incontlst-col">
              <div class="ng-incontlst-bor">
                <div class="ng-incontlst-img ng-oa ng-fault"><a href="[list:link]"><img src="[list:ico]" alt="[list:title]"/></a></div>
                <div class="ng-fault ng-container">
                  <div class="ng-incontlst-tit">
                    <p>[list:title]</p>
                    <span></span></div>
                  <div class="ng-incontlst-text">[list:description]...</div>
                  <a href="[list:link]" class="ng-incontlst-ikk">查看详情</a></div>
              </div>
            </div>
            {/pboot:list} </div>
        </div>
        {/pboot:nav} </div>
    </div>
  </div>
  <div class="ng-inmod ng-fault ng-paddor ng-bg-fff">
    <div class="ng-inmod-ini">
      <div class="ng-fault ng-container">
        <div class="ng-inmod-the ng-container ng-bg-fff"><span class="ng-inmod-the-bg ng-inmod-the-bg-left" aos="fade-down-right"><img src="{pboot:sitedomain}/skin/images/insie1.png"/></span><span class="ng-inmod-the-bg ng-inmod-the-bg-right" aos="fade-up-left"><img src="{pboot:sitedomain}/skin/images/insie2.png"/></span>{pboot:sort scode=8}<span class="ng-inmod-the-cn" aos="fade-down">[sort:name]</span>{/pboot:sort}</div>
        <span class="ng-inmod-thebor" aos="fade-up"></span></div>
      <div class="ng-abst ng-fault ng-container" aos="fade-up">
        <div class="row">
          <div class="col-md-7">
            <div class="ng-abstimg ng-fault"><img src="{pboot:sitedomain}/skin/images/about.jpg"/></div>
          </div>
          <div class="col-md-5">
            <div class="row"> {pboot:nav num=10 parent=5}
              <div class="col-sm-6">
                <div class="ng-fault"><span class="ng-abst-ico"><img src="{pboot:sitedomain}/skin/images/msime[list:i].png" alt="[nav:name]"/></span>
                  <div class="ng-abst-the ng-container ng-fault">
                    <div class="ng-abst-the-tit">[nav:name]</div>
                    <a  href="[nav:link]"  class="ng-abst-the-ikk">More</a></div>
                  <div class="ng-abst-text ng-fault"> [list:description]... </div>
                </div>
              </div>
              {/pboot:nav} </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {pboot:nav num=10 parent=5}
  <div class="ng-inmod ng-fault ng-paddor ng-bg-assist">
    <div class="ng-inmod-ini">
      <div class="ng-fault ng-container">
        <div class="ng-inmod-the ng-container ng-bg-assist"><span class="ng-inmod-the-bg ng-inmod-the-bg-left" aos="fade-down-right"><img src="{pboot:sitedomain}/skin/images/insie1.png" alt="{sort:name}" /></span><span class="ng-inmod-the-bg ng-inmod-the-bg-right" aos="fade-up-left"><img src="{pboot:sitedomain}/skin/images/insie2.png" alt="{sort:name}" /></span><span class="ng-inmod-the-cn" aos="fade-down">{sort:name}</span></div>
        <span class="ng-inmod-thebor" aos="fade-up"></span></div>
      <div class="ng-neswipe ng-fault ng-container ng-bg-fff" aos="fade-up">
        <div class="ng-fault ng-container">
          <div class="ng-inzep swiper-container">
            <div class="swiper-wrapper"> {pboot:list scode=2 num=10 order=date}
              <div class="swiper-slide">
                <div class="ng-inzep-img">
                  <div class="ng-inzep-ims ng-oa"><a href="[list:link]"><img src="[list:ico]" alt="[list:title]"/></a></div>
                  <span class="ng-inzep-ims-bor"></span></div>
                <div class="ng-inzep-iff">
                  <div class="ng-inzep-itit">[list:title]</div>
                  <div class="ng-inzep-idate">[list:date style=Y-m-d]</div>
                  <div class="ng-inzep-text"> [list:description]...</div>
                  <div class="ng-inzep-ikk ng-fault"><a href="[list:link]">点击查看&gt;</a></div>
                </div>
              </div>
              {/pboot:list} </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/pboot:nav}
  <div class="ng-inmod ng-fault ng-paddor ng-bg-fff">
    <div class="ng-inmod-ini">
      <div class="ng-fault ng-container">
        <div class="ng-inmod-the ng-container ng-bg-fff"><span class="ng-inmod-the-bg ng-inmod-the-bg-left" aos="fade-down-right"><img src="{pboot:sitedomain}/skin/images/insie1.png"/></span><span class="ng-inmod-the-bg ng-inmod-the-bg-right" aos="fade-up-left"><img src="{pboot:sitedomain}/skin/images/insie2.png"/></span>{pboot:sort scode=8}<span class="ng-inmod-the-cn" aos="fade-down">[sort:name]</span>{/pboot:sort}</div>
        <span class="ng-inmod-thebor" aos="fade-up"></span></div>
      <div class="ng-ines ng-fault ng-container" aos="fade-up">
        <ul class="ng-ai-drive2">
          {pboot:nav num=10 parent=5}
          <li><a href="javascript:;">[nav:name]</a></li>
          {/pboot:nav}
        </ul>
      </div>
      <div class="ng-isenst ng-fault ng-container ng-ai-drive2_map" aos="fade-up"> {pboot:nav num=10 parent=5}
        <div class="ng-isenst-doc {dede:global name=itemindex runphp="yes"}(@me==1)? @me="ng-isenst-doc-show":@me="";{/dede:global}">
          <div class="row"> {pboot:list scode=2 num=10 order=date}
            <div class="col-md-4 col-xs-6">
              <div class="ng-isenst-bor"><a href="[list:link]"><img src="[list:ico]" alt="[list:title]" class="ng-isenst-img" /><span class="ng-isenst-map"><span style="position:relative;"><span style="display:block;position:absolute; height:22px; line-height:22px; color:#fff;width:100%;top:50%;left:0px;margin-top:-11px;text-align:center;font-size:1.5rem;">[list:title]</span></span></span></a></div>
            </div>
            {/pboot:list} </div>
        </div>
        {/pboot:nav} </div>
    </div>
  </div>
  <!--arop-continerOver--></div>
<!--载入页脚-->
<style>
.jishuzichis a {
    font-size: 12px;
    color: #878787;
}
.ng-siotext {
    line-height: 30px;
}

@media screen and (max-width: 992px) {
.ng-zein-iten-link li {
    width: 50%;
    text-align: center;
}
.ng-zein-iten-link li.li {
    width: 100%;
}
.bdshare-button-style2-16 a, .bdshare-button-style2-16 .bds_more {
    float: initial;
}
.ng-zein-code {
    width: 100%;
}
.ng-zein-code-tit {
    width: 100%;
    text-align: center;
}
}
</style>
<div class="am-end">
  <div class="ng-fault ng-paddor">
    <div class="am-end-ini">
      <div class="ng-zein">
        <div class="ng-zein-iten">
          <div class="ng-zein-iten-link">
            <ul>
              <li aos="fade-up" aos-anchor-placement="top-bottom" aos-delay="100"> {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort}
                {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort} </li>
              <li aos="fade-up" aos-anchor-placement="top-bottom" aos-delay="300"> {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort}
                {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort} </li>
              <li aos="fade-up" aos-anchor-placement="top-bottom" aos-delay="500"> {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort}
                {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort} </li>
              <li aos="fade-up" aos-anchor-placement="top-bottom" aos-delay="500"> {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort}
                {pboot:sort scode=8}
                <div class="ng-zeinkk"><a href="[sort:link]" class="ng-zeinkk-ine">[sort:name]</a></div>
                {/pboot:sort} </li>
              <li class="li" aos="fade-up" aos-anchor-placement="top-bottom" aos-delay="700">
                <div class="ng-zeinkk">推荐我们</div>
                <div class="ng-zeinkk">
                  <div class="bdsharebuttonbox"><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tqf" data-cmd="tqf" title="分享到腾讯朋友"></a><a href="#" class="bds_more" data-cmd="more"></a></div>
                  <!-- <span class="ng-zeinkk-ico"><a href=""><img src="{pboot:sitedomain}/skin/images/smi1.png" alt="" /></a></span><span class="ng-zeinkk-ico"><a href=""><img src="{pboot:sitedomain}/skin/images/smi2.png" alt="" /></a></span><span class="ng-zeinkk-ico"><a href=""><img src="{pboot:sitedomain}/skin/images/smi3.png" alt="" /></a></span><span class="ng-zeinkk-ico"><a href=""><img src="{pboot:sitedomain}/skin/images/smi4.png" alt="" /></a></span> --></div>
              </li>
            </ul>
          </div>
        </div>
        <div class="ng-zein-code" aos="fade-up" aos-anchor-placement="top-bottom" aos-delay="900">
          <div class="ng-zein-code-img"><img src="{pboot:sitedomain}/skin/images/insze.jpg" alt="官方微信"/></div>
          <div class="ng-zein-code-tit">官方微信</div>
        </div>
      </div>
    </div>
  </div>
  <div class="ng-siobox ng-fault ng-paddor">
    <div class="am-end-ini">
      <div class="ng-siotext" aos="fade-up" aos-delay="400" aos-anchor-placement="top-bottom">
        <p> TEL:{pboot:companyphone} &nbsp;&nbsp;&nbsp;QQ:{pboot:companyqq} &nbsp;&nbsp;&nbsp;</p>
        <p> {pboot:sitecopyright} | <a href="https://beian.miit.gov.cn/" target="_blank" rel="nofollow">{pboot:siteicp}</a> | <a href="{pboot:sitedomain}/sitemap.xml" target="_blank">XML地图</a> | <a href="http://www.adminbuy.cn/" target="_blank">网站源码</a> {pboot:sitestatistical}</p>
        <p>公司地址：{pboot:companyaddress}</p>
      </div>
    </div>
  </div>
</div>
<script src="{pboot:sitedomain}/skin/js/jquery.min.js"></script> 
<script src="{pboot:sitedomain}/skin/js/idangerous.swiper.min.js"></script> 
<script src="{pboot:sitedomain}/skin/js/aos.js" type="text/javascript" charset="utf-8"></script> 
<script src="{pboot:sitedomain}/skin/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script> 
<script src="{pboot:sitedomain}/skin/js/jquery.superslide.2.1.1.js"></script> 
<script src="{pboot:sitedomain}/skin/js/app.js"></script> 
<script src="{pboot:sitedomain}/skin/js/jquery-1.7.2.min.js"></script> 
<script src="{pboot:sitedomain}/skin/js/lightbox.js"></script> 

</body>
</html><?php return array (
  0 => 'E:/www7/template/default/html/head.html',
  1 => 'E:/www7/template/default/html/foot.html',
); ?>